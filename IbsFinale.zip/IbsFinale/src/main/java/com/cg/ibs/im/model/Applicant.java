package com.cg.ibs.im.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@NamedQueries({ @NamedQuery(name = "getAllApplicants", query = "select a.applicantId from Applicant a") })
@Entity
@Table(name = "Applicants")
public class Applicant implements Serializable {

	@Id
	@Column(name = "applicant_id", nullable = false, length = 6)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "APP_SQ")
	@SequenceGenerator(sequenceName = "APPLICANT_SEQUENCE", allocationSize = 1, name = "APP_SQ")
	private Long applicantId;
	@Column(name = "First_Name", nullable = false, length = 25)
	private String firstName;
	@Column(name = "Last_Name", nullable = false, length = 25)
	private String lastName;
	@Column(name = "Father_name", nullable = false, length = 40)
	private String fatherName;
	@Column(name = "Mother_Name", nullable = false, length = 40)
	private String motherName;
	@Column(name="dob", nullable = false)
	private LocalDate dob;
	@Enumerated(EnumType.STRING)
	@Column(name= "gender", nullable = false)
	private Gender gender;
	@Column(name = "Mobile_Number", nullable = false, length = 10)
	private String mobileNumber;
	@Column(name = "Alternate_Mobile_Number", length = 10)
	private String alternateMobileNumber;
	@Column(name = "Email_Id", nullable = false, length = 35)
	private String emailId;
	@Column(name = "Aadhar_Number", nullable = false, length = 12)
	private String aadharNumber;
	@Column(name = "Pan_Number", nullable = false, length = 10)
	private String panNumber;
	
	@OneToOne
	private Address address;

	@Lob
	@Column(name = "aadhardocument")
	private byte[] aadharDocument;

	@Lob
	@Column(name = "pandocument")
	private byte[] panDocument;

	public byte[] getAadharDocument() {
		return aadharDocument;
	}

	public Long getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(Long applicantId) {
		this.applicantId = applicantId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getAlternateMobileNumber() {
		return alternateMobileNumber;
	}

	public void setAlternateMobileNumber(String alternateMobileNumber) {
		this.alternateMobileNumber = alternateMobileNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public byte[] getPanDocument() {
		return panDocument;
	}

	public void setPanDocument(byte[] panDocument) {
		this.panDocument = panDocument;
	}

	public void setAadharDocument(byte[] aadharDocument) {
		this.aadharDocument = aadharDocument;
	}

	@Override
	public String toString() {
		return "Applicant [applicantId=" + applicantId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", fatherName=" + fatherName + ", motherName=" + motherName + ", dob=" + dob + ", gender=" + gender
				+ ", mobileNumber=" + mobileNumber + ", alternateMobileNumber=" + alternateMobileNumber + ", emailId="
				+ emailId + ", aadharNumber=" + aadharNumber + ", panNumber=" + panNumber + ", address=" + address
				+ "]";
	}

	

}