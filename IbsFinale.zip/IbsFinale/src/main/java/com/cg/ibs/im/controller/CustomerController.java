package com.cg.ibs.im.controller;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.model.AccountType;
import com.cg.ibs.im.model.Applicant;
import com.cg.ibs.im.model.Application;
import com.cg.ibs.im.model.Customer;
import com.cg.ibs.im.service.BankerService;
import com.cg.ibs.im.service.CustomerService;
 
@RestController
@RequestMapping("/customer")
@Scope("session")
public class CustomerController {
 
    @Autowired
    private CustomerService customerService;
    @Autowired
    private BankerService bankerService;
 
    private Customer cust;
 
    @PostMapping
    public ResponseEntity<String> customerLogin(@RequestBody Customer customer) {
        ResponseEntity<String> result;
 
        try {
            if (customer.getUserId() == null || customer.getUserId().equals("")) {
                result = new ResponseEntity<>("No user details found", HttpStatus.BAD_REQUEST);
            } else {
                try {
                    if (customerService.login(customer.getUserId(), customer.getPassword())) {
                        cust = customerService.getCustomerDetails(customer.getUserId());
                        result = new ResponseEntity<>("Welcome " + cust.getFirstName() + " " + cust.getLastname(), HttpStatus.OK);
                    } else {
                        result = new ResponseEntity<>("Unauthorised User - INCORRECT USERNAME/PASSWORD",
                                HttpStatus.UNAUTHORIZED);
                    }
                } catch (IBSCustomException exception) {
                    result = new ResponseEntity<>("Unauthorised User  - INCORRECT USERNAME/PASSWORD",
                            HttpStatus.UNAUTHORIZED);
                }
            }
 
        } catch (Exception e) {
            e.printStackTrace();
            result = new ResponseEntity<>("Internal Issue", HttpStatus.BAD_REQUEST);
        }
 
        return result;
    }
    @PostMapping(value = "/checkStatus/{applicationId}")
    public ResponseEntity<String> applicationStatus(@PathVariable("applicationId") Long applicationId) {
        ResponseEntity<String> result;
        String message;
        try {
            Application application = bankerService.displayDetails(applicationId);
            String accountType = application.getAccountType().toString();
            message = customerService.checkStatus(applicationId).toString() + "\tRemarks:" + application.getRemarks();
            if (message == null) {
                result = new ResponseEntity<String>("Status couldn't be updated", HttpStatus.BAD_REQUEST);
            } else if (message.equals("APPROVED")) {
                Customer customer = customerService.getCustomerByApplicantId(applicationId);
                if (application.getAccountType() == AccountType.SAVINGS) {
                    Applicant application1 = application.getPrimaryApplicant();
                    message = "Your application has been APPROVED. User ID: " + customer.getUserId() + ", Password: "
                            + customer.getPassword() + ", UCI: " + customer.getUci();
                    result = new ResponseEntity<String>(message, HttpStatus.OK);
                } else {
 
                    Applicant application1 = application.getPrimaryApplicant();
                    Applicant application2 = application.getSecondaryApplicant();
                    Customer customer2 = customerService.getCustomerByApplicantId(applicationId);
                    message = "Your application has been APPROVED. User ID: " + customer.getUserId() + ", Password: "
                            + customer.getPassword() + ", UCI: " + customer.getUci() + ", SECONDARY CUSTOMER: User ID: "
                            + customer2.getUserId() + ", Password: " + customer2.getPassword() + ", UCI: "
                            + customer2.getUci();
                    result = new ResponseEntity<String>(message, HttpStatus.OK);
                }
            } else if (message.equals("DENIED")) {
                result = new ResponseEntity<String>(
                        "Application has been DENIED. Remarks by banker: " + application.getRemarks(), HttpStatus.OK);
            } else {
                result = new ResponseEntity<String>("Application status is PENDING", HttpStatus.OK);
            }
        } catch (IBSCustomException exception) {
            result = new ResponseEntity<String>("Applicant ID is invalid", HttpStatus.BAD_REQUEST);
        }
        return result;
    }
 
    @PostMapping(value = "/updatePassword/{password1}/{password2}")
    public ResponseEntity<String> updateCustomerPassword(@PathVariable("password1") String password1,
            @PathVariable("password2") String password2) {
        ResponseEntity<String> result;
        try {
            if (!customerService.checkCustomerDetails(password1, password2)) {
                result = new ResponseEntity<String>("Passwords don't match. Update failed", HttpStatus.UNAUTHORIZED);
            } else {
                if (cust.getLogin() == 0) {
                    cust.setPassword(password1);
                    if (customerService.updateCustomer(cust)) {
                        result = new ResponseEntity<String>("Welcome " + cust.getFirstName() + " " + cust.getLastname(),
                                HttpStatus.OK);
                    } else {
                        result = new ResponseEntity<String>("Password Updation failed", HttpStatus.BAD_REQUEST);
                    }
                } else {
                    result = new ResponseEntity<String>("Password Updation failed, not your first Login",
                            HttpStatus.BAD_REQUEST);
                }
            }
        } catch (IBSCustomException exception) {
            result = new ResponseEntity<String>("Password Updation failed", HttpStatus.UNAUTHORIZED);
            exception.printStackTrace();
        }
        return result;
    }
 
}