package com.cg.ibs.im;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cg.ibs.im.model.AccountType;
import com.cg.ibs.im.service.BankerService;
import com.cg.ibs.im.ui.Methods;

@SpringBootApplication
public class IbsV8Application implements CommandLineRunner {

	@Autowired
	private Methods methods;

	public static void main(String[] args) {
 
		SpringApplication.run(IbsV8Application.class, args);

	}

	@Override
	public void run(String... args) throws Exception {
 
//		methods.signUp();
		
//		methods.signUpJoint();
		try {
			
//			methods.customerLogin("ssyed", "08MLUmuv");
			
//			methods.firstLogin("schaak");
			
//			methods.approveApplicationToCustomer(50006L);
			
//			methods.print();
			
//			methods.viewApplicantWithId(50006L);
			
//			methods.denyApplication(1L, "no documents");
			
//			methods.viewApplicationApprovals();
			
//			methods.viewApplicationDenials();
			
//			methods.viewApplicationRequests();
			
//			methods.viewApplicationRequestsBanker(5);
			
			System.out.println(methods.bankerLogin("banker1", "pass1"));
			
//			System.out.println(methods.checkStatus(50003L));
		} catch(Exception exception) {
			exception.printStackTrace();
		}
	}

}
