export class Customer {

    public uci: number;
    public firstName: string;
    public lastName: string;
    public fatherName: string;
    public motherName: string;
    public emailId: string;
    public dob: Date;
    public gender: any;
    public mobileNumber:number;
    public alternateMobileNumber:number;
    public aadharNumber:string;
    public panNumber:string;
    public userId: string;
    public password: string;
    public applicationId: number;
    public login:number;
}