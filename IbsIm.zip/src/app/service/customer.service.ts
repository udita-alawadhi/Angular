import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { Customer } from '../model/customer.model';

@Injectable({
    providedIn: 'root'
  })
export class CustomerService {

    baseUrl:string;

    constructor(private http:HttpClient) {
        this.baseUrl=`${environment.baseMwUrlCustomer}`;
    }

    getAll(): Observable<Customer[]> {
        return this.http.get<Customer[]>(this.baseUrl);
      }

    login(customer:Customer): Observable<Customer> {
        return this.http.post<Customer>(this.baseUrl, customer);        
    }
}
