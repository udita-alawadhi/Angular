import { Component, OnInit } from '@angular/core';
import { Customer } from '../model/customer.model';
import { CustomerService } from '../service/customer.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})

export class CustomerComponent implements OnInit {

  customer: Customer;
  customers: Customer[];

  constructor(private custService: CustomerService) {
      this.customer = new Customer();
   }

  ngOnInit() {
    this.load();
  }

  load() {
    this.custService.getAll().subscribe(
      (data) => { this.customers = data; }
    );
  }

  login() {
    if(!this.customer.userId) {
      alert("can't be  umm");
    } else {
      this.custService.login(this.customer).subscribe(
        (data) => {
          this.customer = new Customer();
          this.load();
        }
      );
    }
  }
}
